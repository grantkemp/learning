//: Playground - noun: a place where people can play

import UIKit


let photoToRemove:[String] = ["wasdfadf","asdfasdf","asdfads","adsfadsf","adfasdfds"]

let itemsToDelete = Set(photoToRemove)








